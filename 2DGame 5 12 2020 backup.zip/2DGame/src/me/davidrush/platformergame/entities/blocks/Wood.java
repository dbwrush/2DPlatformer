package me.davidrush.platformergame.entities.blocks;

import me.davidrush.platformergame.gfx.Assets;

public class Wood extends Block{
    public Wood(int x, int y) {
        super(x, y, Assets.wood);
    }
}

