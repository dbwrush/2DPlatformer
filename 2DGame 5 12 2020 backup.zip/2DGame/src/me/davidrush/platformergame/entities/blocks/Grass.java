package me.davidrush.platformergame.entities.blocks;

import me.davidrush.platformergame.gfx.Assets;

public class Grass extends Block{
    public Grass(int x, int y) {
        super(x, y, Assets.grass);
    }
}
