package me.davidrush.platformergame.entities.blocks;

import me.davidrush.platformergame.gfx.Assets;

public class StonePillar extends Block{
    public StonePillar(int x, int y) {
        super(x, y, Assets.stonePillar);
    }
}
