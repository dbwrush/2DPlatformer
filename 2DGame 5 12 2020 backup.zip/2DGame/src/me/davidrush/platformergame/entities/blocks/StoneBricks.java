package me.davidrush.platformergame.entities.blocks;

import me.davidrush.platformergame.gfx.Assets;

public class StoneBricks extends Block{
    public StoneBricks(int x, int y) {
        super(x, y, Assets.stoneBricks);
    }
}
