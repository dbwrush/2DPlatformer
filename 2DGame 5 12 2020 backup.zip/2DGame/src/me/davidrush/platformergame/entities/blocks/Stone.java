package me.davidrush.platformergame.entities.blocks;

import me.davidrush.platformergame.gfx.Assets;

public class Stone extends Block{
    public Stone(int x, int y) {
        super(x, y, Assets.stone);
    }
}
