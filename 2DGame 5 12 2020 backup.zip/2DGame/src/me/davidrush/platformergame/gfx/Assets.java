package me.davidrush.platformergame.gfx;

import java.awt.image.BufferedImage;

public class Assets {

    public static BufferedImage player, grass, stone, stoneBricks, stonePillar, wood;

    public static void init() {
        player = ImageLoader.loadImage("/textures/player.png");
        grass = ImageLoader.loadImage("/textures/grass.png");
        stone = ImageLoader.loadImage("/textures/stone.png");
        stoneBricks = ImageLoader.loadImage("/textures/stoneBricks.png");
        stonePillar = ImageLoader.loadImage("/textures/stoneBricks.png");
        wood = ImageLoader.loadImage("/textures/wood.png");
    }
}
