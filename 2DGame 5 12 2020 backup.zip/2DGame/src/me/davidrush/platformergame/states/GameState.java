package me.davidrush.platformergame.states;

import me.davidrush.platformergame.Game;
import me.davidrush.platformergame.entities.Player;
import me.davidrush.platformergame.gfx.Assets;

import java.awt.*;

public class GameState extends State{

    private Player player;

    public GameState(Game game) {
        super(game);
        player = new Player(game,0, 0);
    }

    @Override
    public void tick() {
        player.tick();
    }

    @Override
    public void render(Graphics g) {
        player.render(g);
    }
}
