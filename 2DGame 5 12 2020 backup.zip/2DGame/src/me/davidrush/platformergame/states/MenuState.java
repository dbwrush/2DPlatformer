package me.davidrush.platformergame.states;

import me.davidrush.platformergame.Game;

import java.awt.*;

public class MenuState extends State{

    public MenuState(Game game) {
        super(game);
    }

    @Override
    public void tick() {

    }

    @Override
    public void render(Graphics g) {

    }
}
